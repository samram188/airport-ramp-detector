import argparse, shutil, random, yaml, os, glob
from pathlib import Path
from tqdm import tqdm

def split_indices(n, train=0.8, val=0.1):
    idx = list(range(n))
    random.shuffle(idx)
    n_train = int(n * train)
    n_val = int(n * val)
    return idx[:n_train], idx[n_train:n_train + n_val], idx[n_train + n_val:]

def main(raw_dir, yolo_dir, seed):
    random.seed(seed)
    raw_dir = Path(raw_dir)
    yolo_dir = Path(yolo_dir)
    for sub in ("images/train", "images/val", "images/test",
                "labels/train", "labels/val", "labels/test"):
        (yolo_dir / sub).mkdir(parents=True, exist_ok=True)

    images = sorted(glob.glob(str(raw_dir / "images" / "*")))
    train_idx, val_idx, test_idx = split_indices(len(images))

    for split, idxs in zip(("train", "val", "test"), (train_idx, val_idx, test_idx)):
        for i in tqdm(idxs, desc=f"→ {split}"):
            img_src = images[i]
            lbl_src = img_src.replace("images", "labels").rsplit(".", 1)[0] + ".txt"
            img_dst = yolo_dir / f"images/{split}/{Path(img_src).name}"
            lbl_dst = yolo_dir / f"labels/{split}/{Path(lbl_src).name}"
            shutil.copy2(img_src, img_dst)
            shutil.copy2(lbl_src, lbl_dst)

    yaml_path = Path("cfg/ramp_aircraft.yaml")
    with open(yaml_path) as f:
        data_yaml = yaml.safe_load(f)
    data_yaml["path"] = str(yolo_dir)
    with open(yaml_path, "w") as f:
        yaml.safe_dump(data_yaml, f)
    print(f"✅ Dataset ready at {yolo_dir}")

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--raw_dir", required=True)
    p.add_argument("--yolo_dir", required=True)
    p.add_argument("--seed", type=int, default=42)
    main(**vars(p.parse_args()))
