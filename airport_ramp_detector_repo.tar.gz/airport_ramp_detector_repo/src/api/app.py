from fastapi import FastAPI, File, UploadFile
from ultralytics import YOLO
import cv2, numpy as np, base64, os

weights_path = os.getenv("RAMP_WEIGHTS", "weights/best.pt")
model = YOLO(weights_path)

app = FastAPI(title="Ramp Detection API")

@app.post("/predict")
async def predict(file: UploadFile = File(...)):
    img = cv2.imdecode(np.frombuffer(await file.read(), np.uint8), cv2.IMREAD_COLOR)
    results = model.predict(img, imgsz=960, conf=0.25)
    annot = results[0].plot()
    _, buf = cv2.imencode(".jpg", annot)
    b64 = base64.b64encode(buf).decode()
    return {"detections": results[0].tojson(), "preview": f"data:image/jpg;base64,{b64}"}
