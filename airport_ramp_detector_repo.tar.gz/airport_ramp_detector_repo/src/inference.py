import argparse
from ultralytics import YOLO

def cli_entry():
    parser = argparse.ArgumentParser()
    parser.add_argument("--weights", required=True)
    parser.add_argument("--source", required=True)
    parser.add_argument("--conf", type=float, default=0.25)
    args = parser.parse_args()
    run(weights=args.weights, source=args.source, conf=args.conf)

def run(weights, source, conf=0.25):
    model = YOLO(weights)
    model.predict(
        source=source,
        imgsz=960,
        conf=conf,
        save=True,
        save_txt=True,
        save_conf=True,
    )

if __name__ == "__main__":
    cli_entry()
