import argparse, datetime, os
from pathlib import Path
from ultralytics import YOLO
import wandb

def main(data, model, epochs, imgsz, batch):
    run_name = f"{Path(model).stem}-{datetime.datetime.now().strftime('%Y%m%d-%H%M%S')}"
    wandb.login(key=os.getenv("WANDB_API_KEY", ""))
    wandb.init(project="ramp-detector", name=run_name, config={
        "model": model, "epochs": epochs, "imgsz": imgsz, "batch": batch
    })
    y = YOLO(model)
    y.train(
        data=data,
        epochs=epochs,
        imgsz=imgsz,
        batch=batch,
        name=run_name,
        project="runs/train",
        patience=25,
        amp=True,
        cos_lr=True,
        callbacks=[wandb.integration.ultralytics.WandbCallback()],
    )
    y.export(format="onnx")
    wandb.finish()

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--model", default="yolov8n.pt")
    ap.add_argument("--epochs", type=int, default=100)
    ap.add_argument("--imgsz", type=int, default=960)
    ap.add_argument("--batch", type=int, default=16)
    main(**vars(ap.parse_args()))
